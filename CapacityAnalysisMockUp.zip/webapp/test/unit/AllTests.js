sap.ui.define([
	"sap/com/CapacityAnalysisMockUp/test/unit/controller/View1.controller"
], function () {
	"use strict";
});